# RPA-Invoice-Scraping-using-UiPath

Robotic Process Automation (RPA) is automating computer tasks by executing software robots on a machine or computer. These robots are configured to mimic human actions while interacting with digital systems and automating business processes.

In this project, we will create a robot that can scrape data from invoices in emails and compile the information in an Excel document. Finally, it will send the completed Excel document via email to the specified User.
